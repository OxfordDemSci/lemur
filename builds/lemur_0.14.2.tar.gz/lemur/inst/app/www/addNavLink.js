$(document).ready(function() {
  $(".navbar .container-fluid .navbar-collapse").append('<ul class="nav navbar-nav navbar-right"><li><a class="nav-image" href="https://demography.cass.anu.edu.au/" target="_blank"><img src="www/logo_anu.png" height="40px"</a></li></ul>');
  $(".navbar .container-fluid .navbar-collapse").append('<ul class="nav navbar-nav navbar-right"><li><a class="nav-image" href="https://www.demographicscience.ox.ac.uk/" target="_blank"><img src="www/logo_oxford.png" height="40px"</a></li></ul>');
  $(".navbar .container-fluid .navbar-collapse").append('<ul class="nav navbar-nav navbar-right"><li><a class="nav-image" href="https://www.sdu.dk/en/om_sdu/institutter_centre/cpop" target="_blank"><img src="www/logo_sdu.png" height="40px"</a></li></ul>');
});
