## Contact
---

**Development team and maintainers**

**Marius D. PASCARIU** PhD
Biometric Risks Modeling Chapter, SCOR Global Life

Prof. **Jose Manuel ABURTO**
University of Oxford

Prof. **Vladimir CANUDAS-ROMO**
Australian National University (ANU)


